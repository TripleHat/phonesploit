# PhoneSploit
Remote Android Management Tool Via ADB

# Made By Metachar/Zucccs

# Steps To Install In Windows
```
git clone https://github.com/cyberknight777/PhoneSploit
Extract Rar File To PhoneSploit Directory
pip install colorama
python main.py
```

# Steps To Install In Linux
```
git clone https://github.com/cyberknight777/PhoneSploit
cd PhoneSploit 
bash linux.sh
```

# Steps To Install In Termux
```
git clone https://github.com/cyberknight777/PhoneSploit
cd PhoneSploit
bash termux.sh
```

#How To Run Tool After Installation
```
cd PhoneSploit 
python2 main_linux.py
